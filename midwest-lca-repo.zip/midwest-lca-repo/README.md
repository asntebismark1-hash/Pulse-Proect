# Midwest Grain & Pulse LCA — State-by-State BART Analysis

A self-contained R pipeline that estimates the **carbon footprint (life-cycle assessment)** of major Midwest field crops — corn, soybeans, wheat, barley, dry beans, dry peas, and lentils — state by state (Iowa, Minnesota, Nebraska, North Dakota, South Dakota), using USDA NASS production data (2010–2024). It then fits a **Bayesian Additive Regression Trees (BART)** model per state to predict carbon intensity with full posterior credible intervals, runs Sobol sensitivity analysis and Monte Carlo uncertainty propagation, and forecasts carbon intensity out to 2030 with BART + ARIMA.

Unlike the other repos in this set, this script is **fully self-contained** — all crop production data is embedded directly in the script (transcribed from USDA NASS), so it runs end-to-end with no external data files or upstream scripts required.

---

## What it does

1. **Builds an embedded USDA NASS dataset** (2010–2024) of production and harvested area for every crop grown in each of the five states (not every state grows every crop — e.g. only North Dakota grows lentils and dry peas at scale).
2. **Calculates a full cradle-to-gate-to-post-gate LCA** for every state–crop–year combination:
   - **Cradle:** fertilizer production (N, P₂O₅, K₂O), seed production, pesticide production
   - **Gate:** field machinery (diesel), irrigation (state-specific electricity grid factors), N₂O emissions from **both** synthetic fertilizer and biological nitrogen fixation (BNF) in legumes/pulses
   - **Post-gate:** drying, storage, processing, transport to elevator
   - **Soil organic carbon (SOC) credit:** amortized over 20 years per IPCC (2019) guidance, with a parallel "without SOC" scenario for comparison
3. **Trains a separate BART model per state** to predict net carbon intensity (kg CO₂e / kg grain) from year, crop identity, production, area, and yield — with full posterior credible intervals (50%/80%/95%) and empirical coverage diagnostics.
4. **Runs Sobol global sensitivity analysis** on the key LCA parameters (N/P/K application rates, diesel use, irrigation fraction, transport distance).
5. **Runs Monte Carlo uncertainty propagation** using triangular distributions on emission factors, reporting coefficient of variation per crop.
6. **Forecasts carbon intensity to 2030** per crop type using BART-predicted historical intensity fed into `auto.arima()`.
7. Produces 13 figures/tables per state, plus 3 cross-state comparison outputs.

## Repository Structure

```
.
├── R/
│   └── midwest_lca_bart.R   # The complete pipeline — data, LCA, BART, sensitivity, forecast
├── data/                    # Created automatically; currently unused (all data is embedded in the script)
├── outputs/                 # All generated CSVs and figures land here (created automatically)
│   └── states/               # Per-state subfolders, each with 13 numbered outputs
├── .gitignore
├── LICENSE
└── README.md
```

## Requirements

```r
install.packages(c(
  "tidyverse", "BART", "forecast", "ggplot2", "scales",
  "sensitivity", "jsonlite", "data.table"
))
```

The script also attempts to auto-install any of these that are missing when it runs (`if (!require(pkg, ...)) install.packages(pkg, ...)`), so a fresh environment should work without manual setup — though pre-installing is faster and more reliable, especially for `BART` which compiles from source on some platforms.

## Usage

```r
source("R/midwest_lca_bart.R")
```

Run from the repository root (or set your working directory there first) so the relative `outputs/`, `outputs/states/`, and `data/` paths resolve correctly — the script creates these directories automatically if they don't exist.

**Runtime note:** this trains one BART model (1000 posterior draws, 200 trees) per state, plus a 500-run Sobol analysis and a 500-iteration Monte Carlo simulation per state — expect this to take a while (minutes, not seconds) on a typical laptop.

## Outputs

### Per state (in `outputs/states/<State_Name>/`)

| # | File | Content |
|---|---|---|
| 01 | `01_carbon_intensity_trend.png` | Carbon intensity over time by crop |
| 02 | `02_lca_breakdown.png` | Cradle/Gate/Post-Gate/SOC-credit stacked breakdown by crop |
| 03 | `03_carbon_intensity_by_crop.png` | Boxplot of carbon intensity by crop, colored by crop type |
| 04 | `04_total_emissions_trend.png` | Total state GHG emissions over time (Mt CO₂e) |
| 05 | `05_detailed_sources.png` | Emissions broken into 8 detailed sources per crop |
| 06 | `06_yield_vs_intensity.png` | Yield vs. carbon intensity scatter, with linear fit per crop |
| 07 | `07_bart_predictions_ci.png` | BART predicted vs. actual carbon intensity, with 80%/95% credible intervals |
| 08 | `08_coverage_diagnostic.png` | Empirical coverage of BART's 50/80/95% intervals, train vs. test |
| 09 | `09_variable_importance.png` | BART variable importance (% of tree splits) |
| 10 | `10_scenario_comparison.png` | With-SOC vs. without-SOC carbon intensity by crop |
| 11 | `11_sobol_sensitivity.png` / `.csv` | Sobol first-order and total-effect sensitivity indices |
| 12 | `12_monte_carlo_uncertainty.png` / `.csv` | Monte Carlo mean/CI/CV per sampled observation |
| 13 | `13_forecast_2030.png` / `.csv` | BART + ARIMA carbon intensity forecast, 2025–2030 |

Plus `bart_credible_intervals.csv` and `variable_importance.csv` with the raw underlying data for outputs 07–09.

### Cross-state (in `outputs/`)

- `lca_with_soc.csv`, `lca_without_soc.csv` — full LCA results for every state/crop/year, both scenarios
- `state_bart_summary.csv` — BART performance (R², RMSE, coverage) summarized per state
- `cross_state_comparison.png` — boxplot of carbon intensity across all five states
- `cross_state_heatmap.png` — state × crop heatmap of mean carbon intensity

## Methodology notes

- **Functional unit:** 1 kg of raw grain at the farm gate.
- **N₂O accounting:** includes emissions from synthetic N fertilizer (1% EF, IPCC Tier 1 default) **and** from biological nitrogen fixation in legumes/pulses (0.2% EF) — this is a deliberate correction, since BNF-derived N₂O is often omitted in simpler LCAs, which would otherwise make legumes/pulses look artificially cleaner than they are.
- **SOC credit:** total 20-year soil carbon accumulation is amortized to an annual credit (kg C/ha/year), per IPCC (2019) guidance on treating soil carbon changes as a flux rather than a one-time credit.
- **Electricity factors:** state-specific, from EPA eGRID 2022 subregional data — this matters a lot here, since North Dakota's grid (0.599 kg CO₂e/kWh) is roughly 4× cleaner-per-unit than South Dakota's (0.148), materially affecting drying/storage/processing emissions across otherwise-similar crops.
- **Data source:** production and harvested-area figures are transcribed from USDA NASS QuickStats (2010–2024). These are embedded directly in the script rather than read from a file — if you want to update to newer years or verify the figures, cross-check against [quickstats.nass.usda.gov](https://quickstats.nass.usda.gov/).

## Notes & Caveats

- All USDA NASS figures are hand-transcribed into the script as literal R vectors — there's no automated data pull, so updating to a new year requires manually editing the relevant `*_data` data frame in Section 3.
- BART training uses `set.seed(123)` and the train/test split is seeded, but exact numerical reproducibility of `BART::wbart()` across R/package versions isn't guaranteed.
- The embedded Sobol sensitivity model (`lca_model_sobol()`) is a simplified re-implementation of the full LCA calculation for tractability — it captures the main fertilizer/machinery/irrigation/N₂O/transport terms but omits smaller components (seed, pesticide, drying, storage) for speed.
- `sobolSalt()` occasionally fails for small state/crop subsets; the script wraps this in `tryCatch()` and simply skips the Sobol outputs for that state if so, without halting the rest of the pipeline.

## License

*(Add a license appropriate for your repository. A placeholder MIT license is included in `LICENSE`; update the copyright holder and year.)*
